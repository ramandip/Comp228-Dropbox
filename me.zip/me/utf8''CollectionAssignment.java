import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.TreeMap;


public class CollectionAssignment {

	public static void main(String[] args) {
		
		Random r = new Random(10000);
		
				List <Number> listLL= new LinkedList <> ();
		long beginTimeLinkedL = System.nanoTime();

		for (int i = 0; i < 10000; i++){
		listLL.add(0, r.nextInt()); //beginning
		}
		long  midTimeLinkedL = System.nanoTime();
		long addBeginLLTime = midTimeLinkedL- beginTimeLinkedL;
		//beginTimeLinkedL = 0;
		//midTimeLinkedL = 0;
		int tempTime = (int) ( addBeginLLTime/1E3);
		addBeginLLTime = tempTime;
		midTimeLinkedL = System.nanoTime();
		for (int i = 0; i < 10000; i++){
			listLL.remove(0); //beginning
		}

		long endT = System.nanoTime();
		long removeBeginLLTime = endT - midTimeLinkedL;
		//endT =0 ;
		//midTimeLinkedL = 0;
		tempTime = (int) ( removeBeginLLTime/1E3);
		removeBeginLLTime = tempTime;
		
		/*========Middle of LinkedList======*/
		
		listLL= new LinkedList <> ();
		beginTimeLinkedL = System.nanoTime();
		
		for (int i = 0; i < 10000; i++){
			listLL.add(listLL.size()/2, r.nextInt());
			
			
		}
		midTimeLinkedL = System.nanoTime();
		long AddMiddleLLtime = midTimeLinkedL- beginTimeLinkedL;
		//beginTimeLinkedL = 0;
		//midTimeLinkedL = 0;
		tempTime = (int) ( AddMiddleLLtime/1E3);
		AddMiddleLLtime = tempTime;

		midTimeLinkedL = System.nanoTime();
		
		//remove the elements from various locations
		for (int i = 0; i < 10000; i++){
			listLL.remove(listLL.size()/2); //middle
		}
		endT = System.nanoTime();
		long removeMiddleLLTime = endT - midTimeLinkedL;
		//endT = 0 ;
		//midTimeLinkedL = 0;
		tempTime = (int) ( removeMiddleLLTime/1E3);
		removeMiddleLLTime = tempTime;
		
		
		
		/*========End of LinkedList======*/
		beginTimeLinkedL = System.nanoTime();
		listLL= new LinkedList <> ();
		
		for (int i = 0; i < 10000; i++){
			listLL.add(r.nextInt());
			
			
		}
		
		midTimeLinkedL = System.nanoTime();
		long AddEndLLtime = midTimeLinkedL- beginTimeLinkedL;
		//beginTimeLinkedL = 0;
		//midTimeLinkedL = 0;
		tempTime = (int) ( AddEndLLtime/1E3);
		AddEndLLtime = tempTime;
		tempTime = 0;
		
		midTimeLinkedL = System.nanoTime();
				//remove the elements from various locations
		for (int i = 0; i < 10000; i++){
			listLL.remove(listLL.size()-1); //end
		}
		endT = System.nanoTime();
		long removeEndLLTime = endT - midTimeLinkedL;
		//midTimeLinkedL =0;
		//endT = 0;
		tempTime = (int) ( removeEndLLTime/1E3);
				removeEndLLTime = tempTime;
				tempTime = 0;
				
		
		System.out.println("time (ms) to: Insert\tStart,\tMiddle,\tEnd;\tDelete \tStart,\tMiddle,\tEnd;"); 
		System.out.println("LinkedList\t\t" +addBeginLLTime/1E3+ "\t"+AddMiddleLLtime/1E3 + "\t"+AddEndLLtime/1E3 + "\t\t"+removeBeginLLTime/1E3+ "\t"+removeMiddleLLTime/1E3  +  "\t"+ removeEndLLTime/1E3);
		
		//LinkedList ends here.
		//ArrayList starts here.
		
		List <Number> listAL= new ArrayList <> ();
		
		beginTimeLinkedL = System.nanoTime();

		for (int i = 0; i < 10000; i++){
			listAL.add(0, r.nextInt()); //beginning
		}
		midTimeLinkedL = System.nanoTime();
		long addBeginALTime = midTimeLinkedL- beginTimeLinkedL;
		//beginTimeLinkedL = 0;
		//midTimeLinkedL = 0;
		tempTime = (int) ( addBeginALTime/1E3);
		addBeginALTime = tempTime;
		//tempTime = 0;
		midTimeLinkedL = System.nanoTime();
		for (int i = 0; i < 10000; i++){
			listAL.remove(0); //beginning
		}

		endT = System.nanoTime();
		long removeBeginALTime = endT - midTimeLinkedL;
		//endT =0 ;
		//midTimeLinkedL = 0;
		tempTime = (int) ( removeBeginALTime/1E3);
		removeBeginALTime = tempTime;
		tempTime = 0;
		
		/*========Middle of ArrayList======*/
		
		listAL= new ArrayList <> ();
		beginTimeLinkedL = System.nanoTime();
		
		for (int i = 0; i < 10000; i++){
			listAL.add(listAL.size()/2, r.nextInt());//middle
			
			
		}
		midTimeLinkedL = System.nanoTime();
		long AddMiddleALtime = midTimeLinkedL- beginTimeLinkedL;
		//beginTimeLinkedL = 0;
		//midTimeLinkedL = 0;
		tempTime = (int) ( AddMiddleALtime/1E3);
		AddMiddleALtime = tempTime;

		midTimeLinkedL = System.nanoTime();
		
		//remove the elements from various locations
		for (int i = 0; i < 10000; i++){
			listAL.remove(listAL.size()/2); //middle
		}
		endT = System.nanoTime();
		long removeMiddleALTime = endT - midTimeLinkedL;
		//endT = 0 ;
		//midTimeLinkedL = 0;
		tempTime = (int) ( removeMiddleALTime/1E3);
		removeMiddleALTime = tempTime;
		
		
		
		/*========End of ArrayList======*/
		beginTimeLinkedL = System.nanoTime();
		listAL= new ArrayList <> ();
		
		for (int i = 0; i < 10000; i++){
			listAL.add(r.nextInt());//end
			
			
		}
		
		midTimeLinkedL = System.nanoTime();
		long AddEndALtime = midTimeLinkedL- beginTimeLinkedL;
		//beginTimeLinkedL = 0;
		//midTimeLinkedL = 0;
		tempTime = (int) ( AddEndALtime/1E3);
		AddEndALtime = tempTime;
		midTimeLinkedL = System.nanoTime();
		
		//remove the elements from various locations
		for (int i = 0; i < 10000; i++){
			listAL.remove(listAL.size()-1); //end
		}
		endT = System.nanoTime();
		long removeEndALTime = endT - midTimeLinkedL;
		//midTimeLinkedL =0;
		//endT = 0;
		tempTime = (int) ( removeEndALTime/1E3);
		removeEndALTime = tempTime;
		
		
		System.out.println("ArrayList\t\t" +addBeginALTime/1E3+ "\t"+AddMiddleALtime/1E3 + "\t"+AddEndALtime/1E3 + "\t\t"+removeBeginALTime/1E3+ "\t"+removeMiddleALTime/1E3  +  "\t"+ removeEndALTime/1E3  );
				
		//ArrayList ends here.
		
		//HashMap Starts here
		
		Map <Number, Object> mapHM = new HashMap<>();
		
		long beginT = System.nanoTime();

		for (int i = 0; i < 10000; i++){
			mapHM.put(i, r);
		}
			long midTimeMap = System.nanoTime();
			long AddStartMaptime = midTimeMap- beginT;
			beginT = 0;
			midTimeMap = 0;
			tempTime = (int) ( AddStartMaptime/1E3);
			AddStartMaptime = tempTime;

			endT = 0;
			midTimeMap = 0;
			midTimeMap = System.nanoTime();
			for (int i = 0; i < 10000; i++){
				mapHM.remove(i); //middle
			}
			

		endT = System.nanoTime();
		long removeBeginHMTime = endT - midTimeMap;
		endT =0 ;
		midTimeLinkedL = 0;
		tempTime = (int) ( removeBeginHMTime/1E3);
		removeBeginALTime = tempTime;
		tempTime = 0;
		
		/*========Middle of HashMap======*/
		
		mapHM = new HashMap<>();
		beginT = System.nanoTime();
		
		for(int i = 0; i <1000; i++ )
		{mapHM.put(i,r);//middle
		}
		
		for(int i = 1001; i <9000; i++ )
		{mapHM.put(i,r);//middle
		}
		
		for(int i = 9001; i <10000; i++ )
		{mapHM.put(i,r);//middle
		}
		
		midTimeLinkedL = System.nanoTime();
		long AddMiddleHMTime = midTimeLinkedL- beginT;
		beginT = 0;
		midTimeLinkedL = 0;
		tempTime = (int) ( AddMiddleHMTime/1E3);
		AddMiddleHMTime = tempTime;

		midTimeLinkedL = System.nanoTime();
		
		//remove the elements from various locations
		
		for(int i = 9001; i <10000; i++ )
		{mapHM.remove(i);//middle
		}
		
		for(int i = 1001; i <9001; i++ )
		{mapHM.remove(i);//middle
		}
		for(int i = 0; i <1001; i++ )
		{mapHM.remove(i);//middle
		}
		
		
		
		
		endT = System.nanoTime();
		long removeMiddleHMTime = endT - midTimeLinkedL;
		endT = 0 ;
		midTimeLinkedL = 0;
		tempTime = (int) ( removeMiddleHMTime/1E3);
		removeMiddleHMTime = tempTime;
		
		
		
		/*========End of HashMap======*/
		beginT = System.nanoTime();
		mapHM = new HashMap<>();
		
		for (int i = 0; i < 10000; i++){
			mapHM.put(i, r);
			
			
		}
		
		midTimeLinkedL = System.nanoTime();
		long AddEndHMTime = midTimeLinkedL- beginT;
		beginT = 0;
		midTimeLinkedL = 0;
		tempTime = (int) ( AddEndHMTime/1E3);
		AddEndHMTime = tempTime;
		midTimeLinkedL = System.nanoTime();
		
		//remove the elements from various locations
		for (int i = 9999; i >= 0; i--){
			mapHM.remove(0); //end
		}
		endT = System.nanoTime();
		long removeEndHMTime = endT - midTimeLinkedL;
		midTimeLinkedL =0;
		endT = 0;
		tempTime = (int) ( removeEndHMTime/1E3);
		removeEndHMTime = tempTime;
		
		
		System.out.println("HashMap\t\t\t" +AddStartMaptime/1E3+ "\t"+AddMiddleHMTime/1E3 + "\t"+AddEndHMTime/1E3 + "\t\t"+removeBeginHMTime/1E3+ "\t"+removeMiddleHMTime/1E3  +  "\t"+ removeEndHMTime/1E3);
				
		//HashMap ends here.

		//TreeMap Starts here
		
		Map <Number, Object> mapTM = new TreeMap<>();
		
		beginT = System.nanoTime();

		for (int i = 0; i < 10000; i++){
			mapTM.put(i, r);
		}
			midTimeMap = System.nanoTime();
			long AddBeginMaptime = midTimeMap- beginT;
			beginT = 0;
			midTimeMap = 0;
			tempTime = (int) ( AddBeginMaptime/1E3);
			AddBeginMaptime = tempTime;

			endT = 0;
			midTimeMap = 0;
			midTimeMap = System.nanoTime();
			for (int i = 0; i < 10000; i++){
				mapTM.remove(i); //middle
			}
			

		endT = System.nanoTime();
		long removeBeginHMTime1 = endT - midTimeMap;
		endT =0 ;
		midTimeMap = 0;
		tempTime = (int) ( removeBeginHMTime1/1E3);
		removeBeginHMTime1 = tempTime;
		tempTime = 0;
		
		/*========Middle of TreeMap======*/
		
		mapTM = new TreeMap<>();
		beginT = System.nanoTime();
		
		for(int i = 0; i <1000; i++ )
		{mapTM.put(i,r);//middle
		}
		
		for(int i = 1001; i <9000; i++ )
		{mapTM.put(i,r);//middle
		}
		
		for(int i = 9001; i <10000; i++ )
		{mapTM.put(i,r);//middle
		}
		
		midTimeLinkedL = System.nanoTime();
		long AddMiddleHMTime1 = midTimeLinkedL- beginT;
		beginT = 0;
		midTimeLinkedL = 0;
		tempTime = (int) ( AddMiddleHMTime1/1E3);
		AddMiddleHMTime1 = tempTime;

		midTimeLinkedL = System.nanoTime();
		
		//remove the elements from various locations
		
		for(int i = 9001; i <10000; i++ )
		{mapTM.remove(i);//middle
		}
		
		for(int i = 1001; i <9000; i++ )
		{mapTM.remove(i);//middle
		}
		for(int i = 0; i <1000; i++ )
		{mapTM.remove(i);//middle
		}
		
		
		
		
		endT = System.nanoTime();
		removeMiddleHMTime = endT - midTimeLinkedL;
		endT = 0 ;
		midTimeLinkedL = 0;
		tempTime = (int) ( removeMiddleHMTime/1E3);
		removeMiddleHMTime = tempTime;
		
		
		
		/*========End of TreeMap======*/
		beginT = System.nanoTime();
		mapTM = new TreeMap<>();
		
		for (int i = 0; i < 10000; i++){
			mapTM.put(i, r);
			
			
		}
		
		midTimeLinkedL = System.nanoTime();
		AddEndHMTime = midTimeLinkedL- beginT;
		beginT = 0;
		midTimeLinkedL = 0;
		tempTime = (int) ( AddEndHMTime/1E3);
		AddEndHMTime = tempTime;
		midTimeLinkedL = System.nanoTime();
		
		//remove the elements from various locations
		for (int i = 9999; i >= 0; i--){
			mapTM.remove(0); //end
		}
		endT = System.nanoTime();
		removeEndHMTime = endT - midTimeLinkedL;
		midTimeLinkedL =0;
		endT = 0;
		tempTime = (int) ( removeEndHMTime/1E3);
		removeEndHMTime = tempTime;
		
		
		System.out.println("TreeMap\t\t\t" +AddBeginMaptime/1E3+ "\t"+AddMiddleHMTime1/1E3 + "\t"+AddEndHMTime/1E3 + "\t\t"+removeBeginHMTime1/1E3+ "\t"+removeMiddleHMTime/1E3  +  "\t"+ removeEndHMTime/1E3);
				
		//TreeMap ends here.

		
		
	}
}
//JDBC 4.3


import java.sql.*;

import javax.swing.*;

import java.awt.*;
import java.awt.event.*;

public class Lab4Jdbc extends JFrame {

final static String DRIVER = "com.mysql.jdbc.Driver";
final static String url = "jdbc:mysql://localhost/Library?"
 + "user=root&password=admin";
//GUI objects

private JTabbedPane tabbedPane;
private JPanel panel1, panel2, panel3,panel2L, panel2R, panel3L, panel3R, panel1L, panel1R;

private JButton insert1,show1,insert2,show2,insert3,show3,insert, show, update2;
private JTextArea displayBook, displayPatron,displayBR;
private JLabel lblPatronid, lblBookId,lblBookAuthor,lblBookTitle,lblBookPubYear,lblPatronId,lblPatronFName,lblPatronLName,lblBRCheckOut,label0, label11, label21, label1, label2, label3, label4, label5, label6, label7, label20;
private JTextField txtPatronid, txtBookId,txtBookAuthor,txtBookTitle,txtBookPubYear,txtPatronId,txtPatronFName,txtPatronLName,txtBRCheckOut;
private JScrollPane scrollPaneBR, scrollPanePatron, scrollPaneBook;

//JDBC objects
Connection c ;
Statement st;
PreparedStatement pst;
private JLabel blank21;


//
public Lab4Jdbc()
{
setTitle( "Tabbed Pane Application" );
setSize( 800, 1200 );
setBackground( Color.gray );

JPanel topPanel = new JPanel();
topPanel.setLayout( new BorderLayout() );
getContentPane().add( topPanel );

// Create the tab pages
createPage1();
createPage2();
createPage3();

// Create a tabbed pane
tabbedPane = new JTabbedPane();
tabbedPane.addTab( "Book", panel1 );
tabbedPane.addTab( "Patron", panel2 );
tabbedPane.addTab( "Library checkout", panel3 );
topPanel.add( tabbedPane, BorderLayout.CENTER );




/*
//create and add the text area to south area of the frame
display=new JTextArea(10,5);
JScrollPane scrollPane = new JScrollPane(display);
add(scrollPane,BorderLayout.SOUTH);
//
pEntry =new JPanel();
GridBagLayout grid = new GridBagLayout();
pEntry.setLayout (grid);
//

lblBookId=new JLabel("Book Id:");
txtBookId=new JTextField(4);
lblBookAuthor=new JLabel("Book Author:");
txtBookAuthor=new JTextField(20);
lblBookTitle=new JLabel("Book Title:");
txtBookTitle=new JTextField(60);
lblBookPubYear=new JLabel("Book Publication Year:");
txtBookPubYear=new JTextField(4);
//
//lblPrice=new JLabel(":");
//txtPrice=new JTextField(20);
//
insert=new JButton("Insert");
show = new JButton("Show");

//add components to the grid
addComponent(pEntry, grid, lblBookId, 0,0,1,1);
addComponent(pEntry, grid,txtBookId, 1,0,1,1);
addComponent(pEntry, grid, lblBookAuthor, 0,1,1,1);
addComponent(pEntry, grid, txtBookAuthor, 1,1,1,1);
addComponent(pEntry, grid, insert, 1,5,1,1);
addComponent(pEntry, grid, lblBookTitle, 0,2,1,1);
addComponent(pEntry, grid, txtBookTitle, 1,2,1,1);
addComponent(pEntry, grid, show, 0,4,1,1);
addComponent(pEntry, grid, insert, 1,4,1,1);
addComponent(pEntry, grid, lblBookPubYear, 0,3,1,1);
addComponent(pEntry, grid, txtBookPubYear, 1,3,1,1);
addComponent(pEntry, grid, show, 0,5,1,1);


add(pEntry,BorderLayout.WEST);
//
ButtonHandler bHandler= new ButtonHandler();
insert.addActionListener(bHandler);
show.addActionListener(bHandler);
//
connect();
*/
}
private void createPage1() {
//
panel1 = new JPanel();
panel1L = new JPanel(new GridLayout(4,2));
panel1R = new JPanel(new GridLayout(4,2));
panel1.setLayout(new BorderLayout() );

label0 = new JLabel("");
panel1L.add(label0);
label1 = new JLabel( "Books information" );
label1.setFont( new Font( "TimesRoman", Font.BOLD, 24 ) );
//label1.setBounds( 10, 0, 150, 20 );
panel1L.add( label1 );


lblBookAuthor = new JLabel( "Author Name" );
//lblBookAuthor.setBounds( 10, 15, 150, 20 );
panel1L.add( lblBookAuthor );


txtBookAuthor = new JTextField();
txtBookAuthor.setBounds( 10, 35, 150, 20 );
panel1L.add( txtBookAuthor );

lblBookTitle = new JLabel( "Title" );
//lblBookTitle.setBounds( 10, 60, 150, 20 );
panel1L.add( lblBookTitle );

txtBookTitle = new JTextField();
//txtBookTitle.setBounds( 10, 80, 150, 20 );
panel1L.add( txtBookTitle );

lblBookPubYear = new JLabel( "Publication Year" );
//lblBookPubYear.setBounds( 10, 105, 150, 20 );
panel1L.add( lblBookPubYear );

txtBookPubYear = new JTextField();
//txtBookPubYear.setBounds( 10, 125, 150, 20 );
panel1L.add( txtBookPubYear );

//label without content
label2 = new JLabel("");
panel1R.add(label2);
label3 = new JLabel("");
panel1R.add(label3);
label4 = new JLabel("");
panel1R.add(label4);
label5 = new JLabel("");
panel1R.add(label5);
label6 = new JLabel("");
panel1R.add(label6);
label7 = new JLabel("");
panel1R.add(label7);

insert1 = new JButton("Insert");
//insert1.setBounds(120, 80, 40, 10);
show1 = new JButton("View");
//show1.setBounds(120, 100, 40, 10);
ButtonHandler bHandler = new ButtonHandler();
insert1.addActionListener(bHandler);
show1.addActionListener(bHandler);
panel1R.add(insert1,BorderLayout.CENTER);
panel1R.add(show1,BorderLayout.SOUTH);

displayBook=new JTextArea(10,5);
scrollPaneBook = new JScrollPane(displayBook);
add(scrollPaneBook,BorderLayout.SOUTH);

panel1.add(panel1L,BorderLayout.WEST);    //set headerPanelTop
panel1.add(panel1R,BorderLayout.EAST);    //set headerPanelBottom



connect();
}
private void createPage2() {
// 
panel2 = new JPanel();
panel2L = new JPanel(new GridLayout(7,0));
panel2R = new JPanel(new GridLayout(4,0));

panel2.setLayout( new BorderLayout() );

label11 = new JLabel( "Patron Information");
label11.setToolTipText("Patron information here.");
label11.setFont( new Font( "TimesRoman", Font.BOLD, 24 ) );
//label11.setBounds( 10, 15, 150, 20 );
panel2L.add( label11 );

lblPatronid = new JLabel("Patron ID");
panel2L.add(lblPatronid);

txtPatronid = new JTextField();
panel2L.add(txtPatronid);

lblPatronFName = new JLabel( "First Name" );
//lblPatronFName.setBounds( 10, 55, 150, 20 );
panel2L.add( lblPatronFName );

txtPatronFName = new JTextField();
//txtPatronFName.setBounds( 10, 75, 150, 20 );
panel2L.add( txtPatronFName );

lblPatronLName = new JLabel( "Last Name:" );
//lblPatronLName.setBounds( 10, 100, 150, 20 );
panel2L.add( lblPatronLName );

txtPatronLName = new JTextField();
//txtPatronLName.setBounds( 10, 120, 150, 20 );
panel2L.add( txtPatronLName );

//blank labels to manage buttons
blank21 = new JLabel("");
//blank21.setSize(100, 15);
JLabel blank22 = new JLabel("");
JLabel blank23 = new JLabel("");
JLabel blank24 = new JLabel("");
JLabel blank25 = new JLabel("");
JLabel blank26 = new JLabel("");


insert2 = new JButton("Insert");
update2 = new JButton("Update");
show2 = new JButton("View");
ButtonHandler bHandler2 = new ButtonHandler();
insert2.addActionListener(bHandler2);
update2.addActionListener(bHandler2);
show2.addActionListener(bHandler2);
panel2R.add(blank21);
panel2R.add(blank22);
//panel2R.add(blank23);
//panel2R.add(blank24);
panel2R.add(insert2);
panel2R.add(blank25);
panel2R.add(update2);
panel2R.add(blank26);
panel2R.add(show2);
panel2R.add(blank23);

displayPatron=new JTextArea(10,5);
scrollPanePatron = new JScrollPane(displayPatron);
add(scrollPanePatron,BorderLayout.SOUTH);
panel2.add(panel2L,BorderLayout.WEST);    //set headerPanelTop
panel2.add(panel2R,BorderLayout.EAST);    //set headerPanelBottom



connect();
}
private void createPage3() {
// 
panel3 = new JPanel();
panel3L = new JPanel(new GridLayout(4,0));
panel3R = new JPanel(new GridLayout(3,0));
panel3.setLayout( new BorderLayout() );


label20 = new JLabel(  );
label21 = new JLabel("Book Reader ");
label21.setFont( new Font( "TimesRoman", Font.BOLD, 24 ) );
label21.setToolTipText("Enter Book reader entries here:");
label21.setBounds( 10, 15, 150, 20 );
panel3L.add(label20);
panel3L.add( label21, BorderLayout.CENTER );


lblPatronId = new JLabel( "Patron ID:" );
lblPatronId.setBounds( 10, 55, 150, 20 );
panel3L.add( lblPatronId );

//txtPatronId
txtPatronId = new JTextField();
txtPatronId.setBounds( 10, 75, 150, 20 );
panel3L.add( txtPatronId );

lblBookId = new JLabel( "Book ID:" );
lblBookId.setBounds( 10, 100, 150, 20 );
panel3L.add( lblBookId );

txtBookId = new JTextField();
txtBookId.setBounds( 10, 120, 150, 20 );
panel3L.add( txtBookId );

lblBRCheckOut = new JLabel( "Checkout Date:" );
lblBRCheckOut.setBounds( 10, 145, 150, 20 );
panel3L.add( lblBRCheckOut );txtBRCheckOut = new JTextField();
txtBRCheckOut.setBounds( 10, 165, 150, 20 );
panel3L.add( txtBRCheckOut );

insert3 = new JButton("Insert");
show3 = new JButton("View");
show = new JButton("Top 10 selling");

insert3.setAlignmentX(Component.RIGHT_ALIGNMENT);
show3.setAlignmentX(Component.RIGHT_ALIGNMENT);
show.setAlignmentX(Component.RIGHT_ALIGNMENT);

ButtonHandler bHandler3 = new ButtonHandler();
insert3.addActionListener(bHandler3);
show3.addActionListener(bHandler3);
show.addActionListener(bHandler3);
JLabel label8 = new JLabel("");
panel3R.add(label8);
JLabel label9 = new JLabel("");
panel3R.add(label9);
JLabel label10 = new JLabel("");
panel3R.add(label10);
panel3R.add(insert3);
JLabel label11 = new JLabel("");
panel3R.add(label11);


JLabel blank31 = new JLabel("   ");
panel3R.add(blank31,BorderLayout.CENTER);
panel3R.add(show3);
panel3R.add(show);

displayBR=new JTextArea(10,5);
scrollPaneBR = new JScrollPane(displayBR);
add(scrollPaneBR,BorderLayout.SOUTH);

panel3.add(panel3L,BorderLayout.WEST);    //set headerPanelTop
panel3.add(panel3R,BorderLayout.EAST);    //set headerPanelBottom

connect();
}
/*public void addComponent(JPanel p, GridBagLayout grid, Component c, int gridx, int gridy,
int gridwidth, int gridheight)
{
GridBagConstraints constr = new GridBagConstraints();
constr.gridx = gridx; //column
constr.gridy = gridy; //row
constr.gridwidth = gridwidth; //number of cells in the row that will be covered
constr.gridheight = gridheight; //number of cells in the column that will be covered
constr.fill = GridBagConstraints.HORIZONTAL; //resize the component horizontally
// add the component
grid.setConstraints(c, constr); //apply the constraints to the grid
p.add(c);
}*/

private class ButtonHandler implements ActionListener
{
/* (non-Javadoc)
 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
 */
/* (non-Javadoc)
 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
 */
public void actionPerformed(ActionEvent e)
{
if(e.getSource()==insert1)
{
    //txtBook
//String bookId = txtBookId.getText();
  //  String bookId = "";
String author = txtBookAuthor.getText();
String title = txtBookTitle.getText();
int pubYear = Integer.parseInt(txtBookPubYear.getText());
insertRowBook(author,title,pubYear);
txtBookAuthor.setText("");
txtBookTitle.setText("");
txtBookPubYear.setText("");
}
else if(e.getSource()==show1)
displayResults1();

if(e.getSource()==insert2)
{
//String patronId = txtPatronId.getText();
//    int patronId = Integer.parseInt(null);
String fname = txtPatronFName.getText();
String lname = txtPatronLName.getText();
insertRowPatron(fname,lname);
//txtPatronFName.setText("");
//txtPatronLName.setText("");
}
else if(e.getSource()==show2)
displayResults2();
else if(e.getSource()==update2)
{
	int patronId = Integer.parseInt(txtPatronid.getText());
	String fname = txtPatronFName.getText();
	String lname = txtPatronLName.getText();
	UpdateRowPatron(patronId,fname,lname);
}
if(e.getSource()==insert3)
{
int pId = Integer.parseInt(txtPatronId.getText());
//Integer pId = Integer.parseInt(txtPatronId.getText());//txtPatronId
Integer bId = Integer.parseInt(txtBookId.getText());//  txtBookId
String pubYear = txtBRCheckOut.getText();
insertRowBR(pId,bId,pubYear);
txtPatronId.setText("");
txtBookId.setText("");
txtBRCheckOut.setText("");
}
else if(e.getSource()==show3)
displayResults3();
else if(e.getSource()==show)
    displayResult3();
}



}
//
public void connect()
{
try
{
Class.forName( DRIVER ).newInstance();
// establish connection to database
c = DriverManager.getConnection( url);

}
catch(ClassNotFoundException e) {
e.printStackTrace();
JOptionPane.showMessageDialog(null, e.getMessage());
//e.printStackTrace();
}
catch(SQLException e) {
e.printStackTrace();
JOptionPane.showMessageDialog(null, e.getMessage());
//e.printStackTrace();
}
catch(Exception e) {
e.printStackTrace();
}

}
//
public void displayResults1()
{
try
{
	displayBR.setText("");
st = c.createStatement();

ResultSet rs = st.executeQuery("SELECT * FROM book");
ResultSetMetaData md = rs.getMetaData();
int row=0;
String info="";
while(rs.next())
{
for( int i=1;i <= md.getColumnCount();i++)
{
info+=md.getColumnName(i)+"\t: "+rs.getObject(i)+"\t";
}
row+=1;
info+="\n";
}
if(row%2 == 0)
    displayBR.setBackground(Color.gray);
else
    displayBR.setBackground(Color.white);
displayBR.setText(info);
rs.close();
}
catch(SQLException e) {
JOptionPane.showMessageDialog(null, e.getMessage());
//e.printStackTrace();
}
}

public void displayResults2()
{
try
{
	displayBR.setText("");
st = c.createStatement();

ResultSet rs = st.executeQuery("SELECT * FROM patron");
ResultSetMetaData md = rs.getMetaData();
int row=0;
String info="";
while(rs.next())
{
for( int i=1;i <= md.getColumnCount();i++)
{
info+=md.getColumnName(i)+"\t: "+rs.getObject(i)+"\t";
}
row+=1;
info+="\n";
}
if(row%2 == 0)
    displayBR.setBackground(Color.gray);
else
    displayBR.setBackground(Color.white);
displayBR.setText(info);
rs.close();
}
catch(SQLException e) {
JOptionPane.showMessageDialog(null, e.getMessage());
//e.printStackTrace();
}
}

public void displayResults3()
{
try
{
st = c.createStatement();

ResultSet rs = st.executeQuery("SELECT * FROM BookReader");
ResultSetMetaData md = rs.getMetaData();
int row=0;
String info="";
while(rs.next())
{
for( int i=1;i <= md.getColumnCount();i++)
{
info+=md.getColumnName(i)+"\t: "+rs.getObject(i)+"\t";
}
row+=1;
info+="\n";
}
if(row%2 == 0)
    displayBR.setBackground(Color.gray);
else
    displayBR.setBackground(Color.yellow);
displayBR.setText(info);
rs.close();
}
catch(SQLException e) {
JOptionPane.showMessageDialog(null, e.getMessage());
//e.printStackTrace();
}
}

//
public void displayResult3(){
    try
    {
    st = c.createStatement();

    ResultSet rs = st.executeQuery("SELECT book_id, author_name, title, COUNT(book_id) AS TotalQuantity FROM BookReader INNER JOIN Book ON Book.id = book_id GROUP BY book_id DESC HAVING COUNT(book_id);");
    ResultSetMetaData md = rs.getMetaData();
    int row=0;
    String info="";
    while(rs.next())
    {
    for( int i=1;i <= md.getColumnCount();i++)
    {
    info+=md.getColumnName(i)+"\t: "+rs.getObject(i)+"\t";
    }
    row+=1;
    info+="\n";
    }
    if(row%2 == 0)
        displayBR.setBackground(Color.lightGray);
    else
        displayBR.setBackground(Color.white);
    displayBR.setText(info);
    rs.close();
    }
    catch(SQLException e) {
    JOptionPane.showMessageDialog(null, e.getMessage());
    //e.printStackTrace();
    }
    }

//
public void insertRowBook(String author, String title, int pubYear)
{
try {

pst = c.prepareStatement("Insert into Book (author_name,title, pub_year) VALUES(?,?,?)");

//pst.setString(1, null);
pst.setString(1, author);
pst.setString(2, title);
pst.setInt(3, pubYear);

//Execute the prepared statement using executeUpdate method:
int val = pst.executeUpdate(); //returns the row count


} catch (SQLException e) {
// 
e.printStackTrace();
}
finally{
System.out.println("Done!");
}}

//@SuppressWarnings("null")
public void insertRowPatron(String fname, String lname)
{
try {

pst = c.prepareStatement("Insert into patron (first_name,last_name) VALUES (?,?)");



//pst.setInt(1, (Integer) null);
pst.setString(1, fname);
pst.setString(2, lname);

//Execute the prepared statement using executeUpdate method:
int val = pst.executeUpdate(); //returns the row count


} catch (SQLException e) {
// TODO Auto-generated catch block
e.printStackTrace();
}
finally{
System.out.println("Done!");
}}

public void insertRowBR(int pId, int bId, String checkDate)
{
try {

pst = c.prepareStatement("Insert into BookReader VALUES (?,?,?)");

pst.setInt(1, pId);
pst.setInt(2, bId);
pst.setString(3, checkDate);


//Execute the prepared statement using executeUpdate method:
int val = pst.executeUpdate(); //returns the row count


} catch (SQLException e) {
// 
e.printStackTrace();
}

finally{
System.out.println("Done!");
}


}
public void UpdateRowPatron(int patronId, String fName, String lName)
{
try {

    //REPLACE INTO patron VALUES (1, 'kevin', 'nash'');
pst = c.prepareStatement("REPLACE INTO patron (id,first_name,last_name) VALUES(?,?,?)");

pst.setInt(1, patronId );
pst.setString(2, fName);
pst.setString(3, lName);

//Execute the prepared statement using executeUpdate method:
int val = pst.executeUpdate(); //returns the row count


} catch (SQLException e) {
// TODO Auto-generated catch block
e.printStackTrace();
}
finally{
System.out.println("Done!");
}}
public static void main(String[] args) {
JFrame frame = new Lab4Jdbc();
frame.setSize(640,360);
frame.setVisible(true);

}

}
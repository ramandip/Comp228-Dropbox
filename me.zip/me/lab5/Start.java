
import java.util.concurrent.ForkJoinPool;

public class Start {
    public static void main(String[] args) {

   //final int TASKSIZE= 250;
      long input = 1234567890l;
    final int TASKSIZE= (int) Math.floor(Math.pow((double)input, 0.5));
        Long beginT = System.nanoTime();

        ForkJoinPool fjp = new ForkJoinPool();
        Stream task = new Stream(TASKSIZE, 0, TASKSIZE-1,input);
        fjp.invoke(task);

        Long endT = System.nanoTime();
        Long timebetweenStartEnd = endT - beginT;
        System.out.println("=====time========\n" +timebetweenStartEnd/1E9);

    }
}
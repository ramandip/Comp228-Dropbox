
public class Calc {
	 public void go(long numberForCalc) {
		double divisor = Math.floor(Math.sqrt(numberForCalc));
	 System.out.println("The Factors are:");
			for(int j = 1; j <= divisor; j++ )
			{
			    if(numberForCalc % j == 0){
			   	System.out.print(j + "\t");
			   	//numberForCalc = numberForCalc/j;
			    } 
			} 
			System.out.println("\n");
			}}  
		
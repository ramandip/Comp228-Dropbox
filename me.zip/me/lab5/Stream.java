
import java.util.concurrent.RecursiveAction;

public class Stream extends RecursiveAction {

    final int CPUCOUNT = Runtime.getRuntime().availableProcessors();
    int MINTASKSIZE= 18000;
    int start;
    int end;
    int forSplit;
    long number;

    Stream(int taskSize, int startPoint, int endPoint,long input) {
        forSplit = taskSize;
        start = startPoint;
        end = endPoint;
        number = input;
    }

    protected void compute() {
    	//for (int i=1;i<=6;i++){
        if (CPUCOUNT == 1 || end - start + 1 <= MINTASKSIZE) {
           System.out.println("Thread is Running already! "+":" + (end - start + 1)+ ":" + start +":" + end);
          // for(int i = start; i <= end; i++) {
                new Calc().go(number);
          // }
        } else {
        	System.out.println("spliting the task size");
            int middle = (start + end)/ 2;
            invokeAll(new Stream(forSplit, start, middle, number));
                    //new Stream(forSplit, middle+1, end, number));
            //System.out.println("InvokeAll"+":" + (ForSplit) + ":" + middle+":" + end);

        }//MINTASKSIZE=MINTASKSIZE/2;}
        
    }
}
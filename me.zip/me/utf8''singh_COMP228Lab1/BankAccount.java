package singh_COMP228Lab1_Ex2;

import java.util.Scanner.*;

import javax.swing.JOptionPane.*;


public class BankAccount {

	private String name; // instance variable
	private double balance;
	
	public BankAccount(String first_name,String last_name, double balance)
			{
		this.name=first_name +" " + last_name;
		if(balance>0.0)
		this.balance=balance;
	}
	public void setName(String name)
	{
		this.name = name; // store the name
	}
	
	public String getName()
	{
		return name; 
	}
	public double getbalance()
	{
		return balance;
	}
	public void deposit(double deposit)
	{
		if (deposit>0.0)
			balance = balance+deposit; 
	}
	public void withdraw(double withdrawl)
	{
		if (withdrawl>0.0 && withdrawl <= balance)
			balance =balance- withdrawl; 
	}	

}

public class BankDriverClass {

	public static void main(String[] args) 
	{
		
		Scanner input = new Scanner(System.in);
		
		BankAccount Account = new BankAccount("Ramandip", "Singh", 0.00);
		
		String selection=JOptionPane.showInputDialog("Select an option  \n 1.Deposit amount \n 2.Withdrawl amount \n 3.View Balance from your account");
		int choice = Integer.parseInt(selection);
		
		if(choice ==1)
		{
			String amount=JOptionPane.showInputDialog("Enter the amount you want to deposite");
			double deposit= Double.parseDouble(amount);
			Account.deposit(deposit);			
			JOptionPane.showMessageDialog(null,"New balance is:"  +Account.getBalance() ," Account holder: " +Account.getName(),JOptionPane.PLAIN_MESSAGE);
		}
		if(choice ==2)
		{
			String amount2=JOptionPane.showInputDialog("Enter the amount you want to withdraw");
			double withdraw= Double.parseDouble(amount2);
			Account.withdraw(withdraw);
			JOptionPane.showMessageDialog(null,"New balance is:"  +Account.getBalance() ," Account holder:" +Account.getName(),JOptionPane.PLAIN_MESSAGE);
		}
		if(choice ==3)
		{
			JOptionPane.showMessageDialog(null,"Account balance is:"  +Account.getBalance() ,"Account holder:" +Account.getName(),JOptionPane.PLAIN_MESSAGE);
		}	
			
		input.close();
	}

}

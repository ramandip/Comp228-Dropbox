package singh_COMP228Lab1_Ex1;

import java.util.Scanner.*;


public class Patient 
{
	private String patientId;
	private String firstName;
	private String lastName;
	private String address;
	private String city;
	private String province;
	private String postalCode;
	
	public Patient()
	{
		//default constructor
	}
	
	public Patient(String patientId,String firstName,String lastName,String address,String city,String province,String postalcode)
	{
		this.patientId  = patientId;
		this.firstName 	= firstName;
		this.lastName 	= lastName;
		this.address	= address;
		this.city	= city;
		this.province	= province;
		this.postalCode	= postalcode;
	}
	
	public String getPatientInfo()
	{
		StringBuffer patientInfo = new StringBuffer();
		
		patientInfo.append("Patient Information patientId::"+this.patientId);
		patientInfo.append("\nfirstName::"+changeCase.toUpperCase(this.firstName));
		patientInfo.append("\nlastname::"+changeCase.toUpperCase(this.lastName));
		patientInfo.append("\naddress::"+this.address);
		patientInfo.append("\ncity::"+this.changeCase.toUpperCase(city));
		patientInfo.append("\nprovince::"+this.changeCase.toUpperCase(province));
		patientInfo.append("\npostalCode"+this.changeCase.toUpperCase(postalCode));
		
		return patientInfo.toString();
	}
	
	public String getFirstName() 
	{
		return firstName;
	}
	public void setFirstName(String firstName) 
	{
		this.firstName = firstName;
	}
	public String getLastName() 
	{
		return lastName;
	}
	public void setLastName(String lastName) 
	{
		this.lastName = lastName;
	}
	public String getAddress() 
	{
		return address;
	}
	public void setAddress(String address) 
	{
		this.address = address;
	}
	public String getCity() 
	{
		return city;
	}
	public void setCity(String city) 
	{
		this.city = city;
	}
	public String getProvince() 
	{
		return province;
	}
	public void setProvince(String province) 
	{
		this.province = province;
	}
	public String getPostalCode() 
	{
		return postalCode;
	}
	public void setPostalCode(String postalCode) 
	{
		this.postalCode = postalCode;
	}

	public String getPatientId() 
	{
		return patientId;
	}

	public void setPatientId(String patientId) 
	{
		this.patientId = patientId;
	}
}

public class PatientDriver 
{
	public static void main(String args[])
	{
		String patientId;
		String firstName;
		String lastName;
		String address;
		String city;
		String province;
		String postalcode;
		
		Scanner in = new Scanner(System.in);
		
		System.out.println(" \n Enter patient Details PatientID");
		patientId = in.nextLine();
		System.out.println("\n Enter patient FirstName");
		firstName = in.nextLine();
		System.out.println("\n Enter patient LastName");
		lastName = in.nextLine();
		System.out.println("\n Enter patient Address");
		address = in.nextLine();
		System.out.println(" \n Enter patient City");
		city = in.nextLine();
		System.out.println("\n Enter patient Province");
		province = in.nextLine();
		System.out.println("\n Enter patient PostalCode");
		postalcode = in.nextLine();
		
		Patient p = new Patient(patientId, firstName, lastName, address, city, province, postalcode);
		System.out.println(p.getPatientInfo());
				
	}

}


import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Lab3 extends JFrame{
	JButton calculateButton;
	JComboBox <String> numberOfCoursesCombo, gradeCombo [];
	JComboBox [] creditHoursCombo;
	//JComboBox [] gradeCombo;
	JLabel creditsL, currentGPA_L, 
			numberOfCoursesL, 
			nrL, courseCodeL, creditHoursL, gradeL,
			finalGPA;
	JPanel topPanel, topPanelUpper, topPanelLower,
			coursePanel, bottomPanel;
	JTextField creditsTF, currentGPA_TF; 
	String [] creditHours = {"1", "2", "3", "4"};
	String [] grade = {"4.5", "4", "3", "2"};

	public Lab3()
	{
		setLayout( new BorderLayout()); 
		topPanel = new JPanel();
		topPanelUpper = new JPanel();
		topPanelLower = new JPanel();
		coursePanel = new JPanel();
		bottomPanel = new JPanel();
		
		creditHoursCombo = new JComboBox [10];
		for (int i= 0; i <10; i++)
			creditHoursCombo [i] = new JComboBox(creditHours);
		
		
		creditsL = new JLabel("Number of Courses");
		currentGPA_L = new JLabel("Current GPA");
		creditsTF = new JTextField (4);
		currentGPA_TF = new JTextField (4);
		finalGPA = new JLabel("Final GPA ");
		topPanelUpper.setLayout(new FlowLayout(FlowLayout.RIGHT));
		topPanelUpper.add(creditsL);
		topPanelUpper.add(creditsTF);
		topPanelUpper.add(currentGPA_L);
		topPanelUpper.add(currentGPA_TF);
		topPanel.setLayout(new BorderLayout());
		topPanel.add(topPanelUpper, BorderLayout.NORTH);
		add(topPanel, BorderLayout.NORTH);
		numberOfCoursesL = new JLabel("Number of courses");
		String []courses = {"0", "1", "2", "3", "4", "5", "6"};
		numberOfCoursesCombo = new JComboBox <String>(courses);
		numberOfCoursesCombo.addActionListener(new ComboListenerClass());
		topPanelLower.setLayout(new FlowLayout(FlowLayout.RIGHT));
		topPanelLower.add(numberOfCoursesL);
		topPanelLower.add(numberOfCoursesCombo);
		topPanel.add(topPanelLower, BorderLayout.SOUTH);

		nrL = new JLabel ("Nr");
		courseCodeL = new JLabel ("Course Code");
		creditHoursL = new JLabel("Credit Hours");
		gradeL = new JLabel ("Grade");
		coursePanel.setLayout(new GridLayout (0, 4));
		coursePanel.add(nrL);
		coursePanel.add(courseCodeL);
		coursePanel.add(creditHoursL);
		coursePanel.add(gradeL);
		for (int i = 0; i< 24; i++)
			coursePanel.add(new JLabel());
		
		calculateButton = new JButton ("Calculate");
		bottomPanel.add(finalGPA);
		bottomPanel.add(calculateButton);
		add(coursePanel, BorderLayout.CENTER);
		add("South", bottomPanel);
	}

	public static void main(String[] args) {
		Lab3 frame = new Lab3();
		frame.setTitle("GPA Calculator");
		frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
		frame.setSize(480,320);
		frame.setVisible(true);
	}
	
	private class ComboListenerClass implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			if (e.getSource() == numberOfCoursesCombo){
				coursePanel.removeAll();
				coursePanel.add(nrL);
				coursePanel.add(courseCodeL);
				coursePanel.add(creditHoursL);
				coursePanel.add(gradeL);
				for (int i = 0; i< numberOfCoursesCombo.getSelectedIndex(); i++){
					coursePanel.add(new JLabel ("   " + Integer.toString(i + 1)));
					coursePanel.add(new JTextField(6));
					coursePanel.add(creditHoursCombo [i]);
					coursePanel.add(new JLabel ("X"));
				}
				coursePanel.revalidate();
			}
		}
		
	}
}





















